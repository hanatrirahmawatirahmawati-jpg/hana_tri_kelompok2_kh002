import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';

// NIM 2024080199 -> digit terakhir 9 (GANJIL)
// Aturan Kode Barang: minimal 6 angka dan 3 angka terakhir = 199
const String kAkhiranKode = '199';
const String kNamaDepan = 'Hana';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const StokBarangApp());
}

class StokBarangApp extends StatelessWidget {
  const StokBarangApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pencatatan Stok Barang',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const FormStokBarangPage(),
    );
  }
}

class FormStokBarangPage extends StatefulWidget {
  const FormStokBarangPage({super.key});

  @override
  State<FormStokBarangPage> createState() => _FormStokBarangPageState();
}

class _FormStokBarangPageState extends State<FormStokBarangPage> {
  final _formKey = GlobalKey<FormState>();

  final _namaBarangController = TextEditingController();
  final _tanggalMasukController = TextEditingController();
  final _tanggalKeluarController = TextEditingController();
  final _kodeBarangController = TextEditingController();
  final _jumlahStokController = TextEditingController();

  bool _isLoading = false;

  @override
  void dispose() {
    _namaBarangController.dispose();
    _tanggalMasukController.dispose();
    _tanggalKeluarController.dispose();
    _kodeBarangController.dispose();
    _jumlahStokController.dispose();
    super.dispose();
  }

  Future<void> _simpanBarang() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      // Semua data berasal dari input pengguna
      final namaBarang = _namaBarangController.text.trim();
      final tanggalMasuk = _tanggalMasukController.text.trim();
      final tanggalKeluar = _tanggalKeluarController.text.trim();

      // String -> int sebelum dikirim ke Firestore
      final kodeBarang = int.parse(_kodeBarangController.text.trim());
      final jumlahStok = int.parse(_jumlahStokController.text.trim());

      await FirebaseFirestore.instance.collection('stok_barang').add({
        'nama_barang': namaBarang,
        'tanggal_masuk': tanggalMasuk,
        'tanggal_keluar': tanggalKeluar,
        'kode_barang': kodeBarang, // Number (int)
        'jumlah_stok': jumlahStok, // Number (int)
        'waktu': FieldValue.serverTimestamp(), // Timestamp dari server
      });

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Data barang berhasil disimpan!'),
          backgroundColor: Colors.green,
        ),
      );

      // Kosongkan kembali seluruh field
      _namaBarangController.clear();
      _tanggalMasukController.clear();
      _tanggalKeluarController.clear();
      _kodeBarangController.clear();
      _jumlahStokController.clear();
      _formKey.currentState!.reset();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal menyimpan data: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Input Stok Barang'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Nama Barang (diawali nama depan mahasiswa)
              TextFormField(
                controller: _namaBarangController,
                decoration: const InputDecoration(
                  labelText: 'Nama Barang',
                  hintText: 'Contoh: $kNamaDepan Buku',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.inventory),
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Nama barang wajib diisi'
                    : null,
              ),
              const SizedBox(height: 16),

              // 2. Tanggal Masuk
              TextFormField(
                controller: _tanggalMasukController,
                decoration: const InputDecoration(
                  labelText: 'Tanggal Masuk Barang',
                  hintText: 'Contoh: 27-11-2026',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.calendar_today),
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Tanggal masuk wajib diisi'
                    : null,
              ),
              const SizedBox(height: 16),

              // 3. Tanggal Keluar
              TextFormField(
                controller: _tanggalKeluarController,
                decoration: const InputDecoration(
                  labelText: 'Tanggal Keluar Barang',
                  hintText: 'Contoh: 30-11-2026',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.calendar_month),
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Tanggal keluar wajib diisi'
                    : null,
              ),
              const SizedBox(height: 16),

              // 4. Kode Barang (min 6 angka, 3 angka terakhir 199)
              TextFormField(
                controller: _kodeBarangController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(
                  labelText: 'Kode Barang',
                  hintText: 'Min 6 angka, diakhiri $kAkhiranKode',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.qr_code),
                ),
                validator: (v) {
                  final kode = v?.trim() ?? '';
                  if (kode.isEmpty) return 'Kode barang wajib diisi';
                  if (int.tryParse(kode) == null) {
                    return 'Kode barang harus berupa angka';
                  }
                  if (kode.length < 6) {
                    return 'Kode barang minimal 6 angka';
                  }
                  if (kode.length > 15) {
                    return 'Kode barang maksimal 15 angka';
                  }
                  if (!kode.endsWith(kAkhiranKode)) {
                    return '3 angka terakhir kode barang harus $kAkhiranKode';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // 5. Jumlah Stok (integer, tidak negatif)
              TextFormField(
                controller: _jumlahStokController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Jumlah Stok',
                  hintText: 'Contoh: 25',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.numbers),
                ),
                validator: (v) {
                  final s = v?.trim() ?? '';
                  if (s.isEmpty) return 'Jumlah stok wajib diisi';
                  final stok = int.tryParse(s);
                  if (stok == null) {
                    return 'Jumlah stok harus berupa bilangan bulat';
                  }
                  if (stok < 0) return 'Jumlah stok tidak boleh negatif';
                  return null;
                },
              ),
              const SizedBox(height: 24),

              ElevatedButton(
                onPressed: _isLoading ? null : _simpanBarang,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: _isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Simpan Barang', style: TextStyle(fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

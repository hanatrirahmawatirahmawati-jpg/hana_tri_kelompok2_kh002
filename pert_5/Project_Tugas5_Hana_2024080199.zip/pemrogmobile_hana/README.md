# Tugas 5 - Pencatatan Stok Barang (Firebase)

Nama : Hana Tri Rahmawati
NIM  : 2024080199 (ganjil) -> Kode Barang min 6 angka, 3 angka terakhir 199

## Cara menjalankan
1. Buka project di Android Studio / VS Code.
2. Hubungkan ke project Firebase MILIK SENDIRI (wajib):
   dart pub global activate flutterfire_cli
   flutterfire configure
   (perintah ini membuat lib/firebase_options.dart dan android/app/google-services.json)
3. Di Firebase Console: Build -> Firestore Database -> Create database (mode test).
4. flutter pub get
5. flutter run -d chrome

## Catatan
- Collection: stok_barang
- kode_barang dan jumlah_stok tersimpan sebagai Number (int)
- Isi data yang diinput: nama_barang, tanggal_masuk, tanggal_keluar, kode_barang, jumlah_stok, waktu

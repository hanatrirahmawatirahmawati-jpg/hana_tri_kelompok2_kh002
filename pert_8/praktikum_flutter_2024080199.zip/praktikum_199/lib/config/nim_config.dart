// NIM: 2024080199 -> 3 digit terakhir = 199
// Angka tengah (9) digeser ke belakang -> 199 (tetap sama)
const int nimN = 199;

const int nimUserId = 1499 + nimN; // 1698
const int nimAdminId = 792 + nimN; // 991

import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'widgets/app_button.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const ProfilePage(),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  // Data mahasiswa
  static const String nama = 'Hana Tri Rahmawati';
  static const String nim = '20240801199';
  static const String prodi = 'Teknik Informatika';
  static const String deskripsi = 'Saya Suka Makan Kue Basi';

  // URL GitHub = alamat dasar + username
  static const String githubBaseUrl = 'https://github.com/';
  static const String githubUsername = 'hanatrirahmawatirahmawati-jpg';

  @override
  Widget build(BuildContext context) {
    // d = digit terakhir NIM 20240801199 -> d = 9
    const double d = 9;

    const double paddingCard = 16 + d; // 25
    const double roundedCard = 8 + d; // 17
    const double tinggiTombol = 40 + d; // 49
    const double roundedTombol = 4 + d; // 13
    const double diameterAvatar = 40 + (2 * d); // 58
    const double radiusAvatar = diameterAvatar / 2; // 29
    const double jarakNamaNim = 8 + d; // 17

    return Scaffold(
      appBar: AppBar(
        title: const Text('Personal Profile Card'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(roundedCard),
            ),
            child: Padding(
              padding: const EdgeInsets.all(paddingCard),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircleAvatar(
                    radius: radiusAvatar,
                    child: Icon(Icons.person, size: radiusAvatar),
                  ),
                  const SizedBox(height: 16),
                  const Text(nama),
                  const SizedBox(height: jarakNamaNim),
                  const Text(nim),
                  const SizedBox(height: 8),
                  const Text(prodi),
                  const SizedBox(height: 12),
                  const Text(
                    deskripsi,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  const AppButton(
                    label: 'Kunjungi GitHub Saya',
                    icon: Icons.open_in_new,
                    url: '$githubBaseUrl$githubUsername',
                    height: tinggiTombol,
                    borderRadius: roundedTombol,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

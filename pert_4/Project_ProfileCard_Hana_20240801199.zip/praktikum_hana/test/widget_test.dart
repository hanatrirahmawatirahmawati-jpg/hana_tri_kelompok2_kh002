import 'package:flutter_test/flutter_test.dart';
import 'package:praktikum_androidstudio/main.dart';

void main() {
  testWidgets('Profile card menampilkan identitas', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    expect(find.text('Hana Tri Rahmawati'), findsOneWidget);
    expect(find.text('20240801199'), findsOneWidget);
    expect(find.text('Kunjungi GitHub Saya'), findsOneWidget);
  });
}

# Personal Profile Card

Nama : Hana Tri Rahmawati
NIM  : 20240801199  (d = 9)

Ukuran komponen (d = digit terakhir NIM = 9):
- Padding card        = 16 + 9      = 25
- Rounded card        = 8 + 9       = 17
- Tinggi tombol       = 40 + 9      = 49
- Rounded tombol      = 4 + 9       = 13
- Diameter avatar     = 40 + (2x9)  = 58  (radius 29)
- Jarak nama dan NIM  = 8 + 9       = 17

Jalankan: flutter pub get && flutter run -d chrome
